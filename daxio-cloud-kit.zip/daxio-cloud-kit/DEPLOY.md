# Launch Daxio — Click-by-Click Deploy Guide

Welcome! This guide takes you from "I have the code" to "my app is live on the
internet" — even if you have **never written a line of code**. You'll copy, paste,
and click. Nothing more.

It takes about **45–60 minutes** the first time, and costs **$0 to start**
(see [What it costs](#what-it-costs) at the bottom).

### The three free services we'll use (and what each one does)

| Service | Plain-English job | Think of it as… |
| --- | --- | --- |
| **Supabase** | Stores your accounts, projects, comments, and handles login | The filing cabinet + the front-door key |
| **Cloudflare R2** | Stores the actual big files (your videos and images) | The warehouse for heavy boxes |
| **Cloudflare Pages** | Serves your website to visitors, for free, worldwide | The storefront people actually visit |

A few words you'll see, decoded once so they're not scary later:

- **Environment variable** — a secret setting (like a password) you type into a
  dashboard once. The app reads it; visitors never see it.
- **API key** — a long random string that acts like a password between programs.
- **CORS** — a browser safety rule that says "which websites are allowed to talk
  to this storage." We'll add your site to the allowed list.
- **DNS** — the internet's address book that points your domain name to your site.

> Tip: open this guide on one side of your screen and the dashboards on the other.
> Do the steps **in order** — later steps need values you copy in earlier steps.
> Keep a blank note open to paste the keys you collect; you'll need them in Step 4.

---

## Step 1 — Supabase (accounts, database & login)

1. Go to **https://supabase.com** and click **Start your project** (sign in with
   GitHub or email — both free).
2. Click **New project**.
   - **Name:** `daxio` (anything you like).
   - **Database Password:** click **Generate a password**, then copy it somewhere
     safe. You won't need it for this guide, but don't lose it.
   - **Region:** pick the one closest to you or your team.
   - Click **Create new project** and wait ~2 minutes while it sets up.
3. **Create the database tables.** In the left sidebar, click **SQL Editor**, then
   **+ New query**.
   - Open the file **`supabase-schema.sql`** (it's in this same folder), select
     **all** of it (Ctrl/Cmd+A), and copy it.
   - Paste it into the big empty box in the SQL Editor.
   - Click the green **Run** button (bottom-right). You should see
     **"Success. No rows returned"** — that's exactly what we want. It just built
     all your tables, security rules, and live-comment streaming in one shot.
4. **Turn on the login methods.** In the left sidebar click **Authentication**,
   then **Providers** (under "Configuration" / "Sign In / Up").
   - **Email** — toggle it **ON** (this gives passwordless "magic link" sign-in).
   - **Google** — toggle **ON**. It will ask for a *Client ID* and *Client Secret*.
     - These come from Google's free **Google Cloud Console**
       (https://console.cloud.google.com → **APIs & Services → Credentials →
       Create OAuth client ID → Web application**). Copy Supabase's
       **Redirect URL** (shown right there on the provider screen) into Google's
       "Authorized redirect URIs", then paste Google's Client ID + Secret back
       into Supabase and click **Save**.
   - **Azure (Microsoft)** — toggle **ON** if your team uses Microsoft accounts.
     Same idea: register a free app at https://portal.azure.com → **Microsoft
     Entra ID → App registrations → New registration**, copy Supabase's Redirect
     URL into Azure's "Redirect URI", then paste Azure's *Application (client) ID*
     and a *client secret* back into Supabase and **Save**.

   > Don't have time to set up Google/Azure right now? That's fine — leave just
   > **Email** on. You can return and enable the others any time. The app works
   > with magic-link email alone.

5. **Copy your three keys.** In the left sidebar go to **Project Settings**
   (the gear) → **API**. Paste these into your note — you'll need them in Step 4:

   | What to copy on this page | Goes into the variable named |
   | --- | --- |
   | **Project URL** (e.g. `https://abcd1234.supabase.co`) | `SUPABASE_URL` |
   | **Project API keys → `anon` `public`** | `SUPABASE_ANON_KEY` |
   | **Project API keys → `service_role`** (click "Reveal") | `SUPABASE_SERVICE_ROLE` |

   > **`service_role` is a master key — keep it secret.** It only ever goes into
   > the Cloudflare server settings in Step 4. Never put it in a file, an email,
   > or anywhere a website visitor could see it.

---

## Step 2 — Cloudflare R2 (storage for your videos & images)

R2 is where the heavy files live. Your visitors upload **straight to R2** from
their browser, so even a 20 GB video never slows down your app.

1. Go to **https://dash.cloudflare.com** and sign up / log in (free).
2. In the left sidebar click **R2**. If it's your first time it'll ask you to
   **add a payment method** to *activate* R2 — this is normal and you still pay
   **$0** under the free tier (10 GB of storage free; see costs section).
3. Click **Create bucket**.
   - **Bucket name:** `daxio-uploads` (lowercase, no spaces). Remember this exact
     name — it becomes your `R2_BUCKET` value.
   - Leave the defaults and click **Create bucket**.
4. **Create the S3 API token** (this is the key the app uses to hand out upload
   passes). In R2, click **Manage R2 API Tokens** (top-right) → **Create API
   token**.
   - **Permissions:** choose **Object Read & Write**.
   - **Specify bucket(s):** limit it to your `daxio-uploads` bucket (safer).
   - Click **Create API Token**. The next screen shows three values **once** —
     copy all three into your note now (you can't see the secret again):

   | What R2 shows you | Goes into the variable named |
   | --- | --- |
   | **Account ID** (also on the R2 Overview page, right sidebar) | `R2_ACCOUNT_ID` |
   | **Access Key ID** | `R2_ACCESS_KEY_ID` |
   | **Secret Access Key** | `R2_SECRET_ACCESS_KEY` |

5. **Set the bucket's CORS** so your website is allowed to upload to it. Open your
   bucket → **Settings** tab → scroll to **CORS Policy** → **Edit** → paste the
   JSON below → **Save**.

   ```json
   [
     {
       "AllowedOrigins": ["https://YOUR-SITE.pages.dev", "https://YOUR-DOMAIN.com"],
       "AllowedMethods": ["PUT", "GET", "HEAD"],
       "AllowedHeaders": ["*"],
       "ExposeHeaders": ["ETag"],
       "MaxAgeSeconds": 3600
     }
   ]
   ```

   > Replace the two `AllowedOrigins` with your real site address(es). You'll know
   > your `*.pages.dev` address after Step 4 — it's fine to come back and edit this
   > then. While testing locally you can also add `"http://localhost:8788"`.
   > "Origins" just means "which websites are allowed to send files here."

6. **(Optional but recommended) Give the bucket a public address.** This is the
   `R2_PUBLIC_BASE` — the web address where uploaded files can be viewed.
   - Easiest: bucket → **Settings** → **Public access** → enable the **r2.dev**
     subdomain. Copy that URL (e.g. `https://pub-xxxxx.r2.dev`).
   - Nicer: under **Public access → Custom Domains**, connect a subdomain you own
     like `files.yourdomain.com` (free, gives you a clean URL).
   - Either way, paste the chosen URL into your note as `R2_PUBLIC_BASE`
     (no trailing slash).

You should now have collected all eight server values. Quick checklist:

- [ ] `SUPABASE_URL`
- [ ] `SUPABASE_ANON_KEY`
- [ ] `SUPABASE_SERVICE_ROLE`
- [ ] `R2_ACCOUNT_ID`
- [ ] `R2_ACCESS_KEY_ID`
- [ ] `R2_SECRET_ACCESS_KEY`
- [ ] `R2_BUCKET`
- [ ] `R2_PUBLIC_BASE`

(These eight names are exactly what's documented in **`.env.example`** in this
folder — that file is your reference card, not something you upload.)

---

## Step 3 — Put the code on GitHub

Cloudflare Pages deploys your site straight from a GitHub repository and
re-deploys automatically every time the code changes. We just need to get this
**`launch-cloud`** folder onto GitHub.

**The no-typing way (recommended for non-developers):**

1. Go to **https://github.com** and sign up / log in (free).
2. Click the **+** (top-right) → **New repository**.
   - **Name:** `daxio`. Set it to **Private** if you like. Click
     **Create repository**.
3. On the new empty repo page, click **uploading an existing file** (the link in
   "…or upload an existing file").
4. Open the **`launch-cloud`** folder on your computer, select **everything inside
   it** (the `public` folder, the `functions` folder, `supabase-schema.sql`,
   `_headers`, etc.), and drag it all into the GitHub upload box.
   - **Important:** upload the *contents* of `launch-cloud`, so that `public` and
     `functions` sit at the **top level** of the repo.
   - Do **not** upload a real `config.js` or any file with secret keys — those are
     git-ignored on purpose. The example files (`config.example.js`,
     `.env.example`) are safe and *should* be included.
5. Click **Commit changes**. Your code is now on GitHub.

> Already comfortable with Git? Just `git init` inside `launch-cloud`, commit, and
> push to your new repo — same result.

---

## Step 4 — Cloudflare Pages (publish the website + add the secrets)

1. In the Cloudflare dashboard, left sidebar → **Workers & Pages** → **Create** →
   **Pages** tab → **Connect to Git**.
2. Authorize GitHub if asked, then **select your `daxio` repository** → **Begin
   setup**.
3. **Build settings** — Daxio has **no build step**, so keep these simple:
   - **Framework preset:** **None**.
   - **Build command:** leave **empty**.
   - **Build output directory:** type **`public`**.
   - Cloudflare automatically finds your serverless code in the **`functions`**
     folder — you don't configure anything for that.
4. **Add the server environment variables.** Expand **Environment variables
   (advanced)**. Click **Add variable** once for each of the eight values you
   collected, typing the **name on the left** and pasting the **value on the
   right**. The names must match **exactly** (capital letters, underscores):

   ```
   SUPABASE_URL
   SUPABASE_ANON_KEY
   SUPABASE_SERVICE_ROLE
   R2_ACCOUNT_ID
   R2_ACCESS_KEY_ID
   R2_SECRET_ACCESS_KEY
   R2_BUCKET
   R2_PUBLIC_BASE
   ```

   > For the three sensitive ones (`SUPABASE_SERVICE_ROLE`,
   > `R2_SECRET_ACCESS_KEY`, `R2_ACCESS_KEY_ID`) click the **Encrypt** button so
   > they're stored hidden. Cloudflare keeps them secret and only your server-side
   > functions can read them.

5. Click **Save and Deploy**. Wait ~1–2 minutes. Cloudflare gives you a live
   address like **`https://daxio-abc.pages.dev`** — click it; your site is online!

6. **Two small finishing touches:**
   - **Add the public browser config.** The app needs a tiny public file named
     `config.js`. The simplest path: on GitHub, copy **`public/config.example.js`**
     to **`public/config.js`**, open it, and replace the two placeholder values
     with your real **`SUPABASE_URL`** and **`SUPABASE_ANON_KEY`** (the `anon`
     key only — never the service_role key). Commit it. Cloudflare auto-redeploys.
     *(This file is normally git-ignored; adding it here is what makes the browser
     able to reach Supabase. Only the public URL + anon key go in it, both of
     which are safe to expose.)*
   - **Go back to your R2 CORS (Step 2.5)** and make sure your real
     `*.pages.dev` address is listed in `AllowedOrigins`, so uploads are allowed.

> Changed an environment variable later? You must click **Retry deployment** (or
> push any commit) for Pages to pick up the new value.

---

## Step 5 — Custom domain (optional, free HTTPS)

Want `review.yourbrand.com` instead of `daxio-abc.pages.dev`? It's free and
includes an automatic HTTPS lock icon.

1. In your Pages project, open the **Custom domains** tab → **Set up a custom
   domain**.
2. Type the domain or subdomain you want (e.g. `review.yourbrand.com`) → **Continue**.
3. **Update DNS** — point your domain at Cloudflare:
   - **If your domain is already on Cloudflare:** it adds the record for you —
     just click **Activate domain**. Done.
   - **If your domain is elsewhere** (GoDaddy, Namecheap, etc.): Cloudflare shows
     you a **CNAME** record to add. Log in to your domain registrar, find **DNS
     settings**, and add that CNAME exactly as shown.
4. Wait a few minutes (sometimes up to an hour) for the green **Active** status.
   HTTPS is issued automatically — no certificates to buy or install.
5. **Update two things to match your new domain:**
   - R2 **CORS** `AllowedOrigins` (Step 2.5) — add `https://review.yourbrand.com`.
   - Supabase → **Authentication → URL Configuration** — set the **Site URL** to
     your new domain so magic-link and Google/Microsoft logins redirect back
     correctly.

Happy with the free `*.pages.dev` address? You can skip this entire step.

---

## Test it works

Visit your live site and walk through this checklist. If every box ticks, you've
launched. 🎉

- [ ] **The page loads** with no errors. (Press F12 → **Console** tab; it should be
      clean. A red "Missing Supabase config" message means `config.js` is missing
      or has placeholder values — revisit Step 4.6.)
- [ ] **Sign in works.** Use **Continue with email**, check your inbox for the
      magic link, and click it — you should land back in the app, signed in.
      (And/or test the Google / Microsoft buttons if you enabled them.)
- [ ] **Create a workspace, a project, and an asset.** They appear immediately and
      are still there after a page refresh (proof the Supabase database is saving).
- [ ] **Upload an image or video.** The progress bar should move, then the file
      previews. (If upload fails, it's almost always **R2 CORS** — confirm your
      exact site address is in `AllowedOrigins` from Step 2.5.)
- [ ] **Leave a comment**, then open the same asset in a second browser tab — the
      comment shows up **live** without refreshing (proof realtime is working).
- [ ] **Create a share link** and open it in a private/incognito window (no
      account). The shared asset and comments should load for the outside viewer.

If something's off, the **Console** (F12) and Cloudflare's **Pages → your project
→ Deployments → (latest) → Functions logs** are the two best places to see the
real error message.

---

## What it costs

The honest answer: **$0 to start**, and it scales gently.

| Service | Free tier (plenty for launch & small teams) | When you'd pay |
| --- | --- | --- |
| **Supabase** | 500 MB database, 50,000 monthly active users, social logins | ~$25/mo Pro only when you outgrow the free database or need daily backups |
| **Cloudflare Pages** | Unlimited sites, unlimited bandwidth, 100,000 function requests/day | Essentially never for an app this size |
| **Cloudflare R2** | 10 GB stored free, and **zero egress fees** (no charge to *serve* files) | ~$0.015 per extra GB stored per month — cents, not dollars |
| **Custom domain + HTTPS** | Free (you only pay your registrar's normal ~$10/yr for the domain itself) | — |

**The one thing that costs real money, only if you need it:** raw video files (the
ones in R2) play fine for small clips, but if you want big videos (think 20 GB
masters) to stream smoothly and compress automatically across devices, you'd add
**Cloudflare Stream** at roughly **$5 per 1,000 minutes** stored, plus a small
per-minute delivery fee. You do **not** need this to launch — start with plain R2
playback and turn on Stream later if and when large-video streaming becomes a real
need. (The database already has a `stream_uid` column waiting for that day.)

**Bottom line:** you can run Daxio for a real small team at **$0/month**. Your
first dollar of cost only appears when you either store a lot of media or decide
you want polished large-video streaming.

---

That's it — you're live. Bookmark your Cloudflare **Pages → Deployments** page;
every time you (or anyone) updates the code on GitHub, your site redeploys
automatically within a minute.
