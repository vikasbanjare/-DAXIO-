// ============================================================
// /functions/api/upload-url.js  —  Cloudflare Pages Function
// ------------------------------------------------------------
// Mints a short-lived, browser-uploadable PUT URL for Cloudflare R2.
//
// Flow:
//   1. Browser POSTs { filename, contentType } with a Supabase JWT in the
//      Authorization header.
//   2. We verify that JWT against Supabase's /auth/v1/user endpoint.
//   3. We build a per-object key and PRESIGN an S3 PUT request to R2 using
//      AWS Signature Version 4 — implemented from scratch with Web Crypto
//      (crypto.subtle) so the function stays ZERO-dependency on the Workers
//      runtime (no aws-sdk, no npm).
//   4. We return { uploadUrl, key, publicUrl }. The browser then does a plain
//      PUT (no auth header, no extra signed headers) straight to R2 — big
//      files never transit our server.
//
// SECURITY NOTE: this is the most sensitive file in the kit. The presign must
// be byte-exact or R2 rejects the upload with SignatureDoesNotMatch, so every
// step below is commented. Secrets (R2 keys, service role) live only in
// Cloudflare env and never reach the browser.
// ============================================================

// --- CORS ---------------------------------------------------
// Permissive CORS so the static frontend (possibly a different origin during
// local dev / preview) can call this endpoint and read the JSON response.
const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Authorization, Content-Type',
  'Access-Control-Max-Age': '86400',
};

// Small helper: JSON response with CORS headers attached.
function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json', ...CORS_HEADERS },
  });
}

// ------------------------------------------------------------
// Web Crypto primitives for SigV4
// ------------------------------------------------------------

const encoder = new TextEncoder();

// Lowercase hex encoding of a byte buffer (SigV4 expects lowercase hex).
function toHex(buffer) {
  const bytes = new Uint8Array(buffer);
  let out = '';
  for (let i = 0; i < bytes.length; i++) {
    out += bytes[i].toString(16).padStart(2, '0');
  }
  return out;
}

// SHA-256 of a string -> lowercase hex digest.
async function sha256Hex(message) {
  const digest = await crypto.subtle.digest('SHA-256', encoder.encode(message));
  return toHex(digest);
}

// HMAC-SHA256(key, message) -> raw bytes (ArrayBuffer).
// `key` may be either an ArrayBuffer/Uint8Array (from a previous round) or a
// string (the initial "AWS4" + secret). We normalize to bytes before importing.
async function hmac(key, message) {
  const keyBytes = typeof key === 'string' ? encoder.encode(key) : key;
  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    keyBytes,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign'],
  );
  return crypto.subtle.sign('HMAC', cryptoKey, encoder.encode(message));
}

// Derive the SigV4 signing key:
//   kDate    = HMAC("AWS4" + secret, date)
//   kRegion  = HMAC(kDate,   region)
//   kService = HMAC(kRegion, service)
//   kSigning = HMAC(kService,"aws4_request")
// Each HMAC consumes the *raw bytes* of the previous one (a classic SigV4 gotcha).
async function getSigningKey(secretKey, dateStamp, region, service) {
  const kDate = await hmac('AWS4' + secretKey, dateStamp);
  const kRegion = await hmac(kDate, region);
  const kService = await hmac(kRegion, service);
  const kSigning = await hmac(kService, 'aws4_request');
  return kSigning;
}

// RFC-3986 encoding for query-string values. encodeURIComponent leaves
// !'()* unescaped, but SigV4's canonical query string requires them escaped,
// so we percent-encode those four extra characters by hand.
function rfc3986(str) {
  return encodeURIComponent(str).replace(
    /[!'()*]/g,
    (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase(),
  );
}

// Encode an object-key path for the canonical URI. Each "/" separates path
// segments and must stay literal; everything inside a segment is rfc3986-encoded.
function encodeKeyPath(key) {
  return key
    .split('/')
    .map((segment) => rfc3986(segment))
    .join('/');
}

// ------------------------------------------------------------
// CORS preflight
// ------------------------------------------------------------
export async function onRequestOptions() {
  // 204 No Content with the CORS headers satisfies the browser preflight.
  return new Response(null, { status: 204, headers: CORS_HEADERS });
}

// ------------------------------------------------------------
// POST /api/upload-url
// ------------------------------------------------------------
export async function onRequestPost(context) {
  const { request, env } = context;

  // --- 1) Parse and validate the request body ----------------
  let payload;
  try {
    payload = await request.json();
  } catch {
    return json({ error: 'Invalid JSON body' }, 400);
  }
  const { filename, contentType } = payload || {};
  if (!filename || typeof filename !== 'string') {
    return json({ error: 'filename is required' }, 400);
  }

  // --- 2) Verify the Supabase JWT ----------------------------
  // The client sends `Authorization: Bearer <access_token>`. We forward it to
  // Supabase's user endpoint along with the anon apikey; a 200 means the token
  // is valid and unexpired. Anything else -> 401 (we do not mint a URL).
  const authHeader = request.headers.get('Authorization') || '';
  if (!authHeader.startsWith('Bearer ')) {
    return json({ error: 'Missing bearer token' }, 401);
  }
  const userResp = await fetch(`${env.SUPABASE_URL}/auth/v1/user`, {
    headers: {
      apikey: env.SUPABASE_ANON_KEY,
      Authorization: authHeader,
    },
  });
  if (!userResp.ok) {
    return json({ error: 'Unauthorized' }, 401);
  }

  // --- 3) Build a collision-proof, sanitized object key ------
  // Prefix with a UUID so two users uploading "final.mp4" never clobber each
  // other; sanitize the original name to keep the URL/path safe.
  const safeName = filename.replace(/[^\w.-]+/g, '_');
  const key = 'uploads/' + crypto.randomUUID() + '-' + safeName;

  // --- 4) AWS SigV4 query-string presign for an R2 PUT -------
  const region = 'auto';
  const service = 's3';
  const host = `${env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`;
  // Path-style addressing: /<bucket>/<key>. The bucket name is a literal path
  // segment; the key gets per-segment RFC-3986 encoding.
  const canonicalUri = `/${env.R2_BUCKET}/${encodeKeyPath(key)}`;

  // SigV4 timestamps: amzDate = YYYYMMDDTHHMMSSZ, dateStamp = YYYYMMDD (UTC).
  const now = new Date();
  const amzDate = now.toISOString().replace(/[:-]|\.\d{3}/g, ''); // 20260621T010203Z
  const dateStamp = amzDate.slice(0, 8); // 20260621

  const expires = 3600; // URL valid for 1 hour
  const algorithm = 'AWS4-HMAC-SHA256';
  const credentialScope = `${dateStamp}/${region}/${service}/aws4_request`;

  // For a presigned URL the auth material rides in the query string, not in
  // headers. We sign ONLY the host header (signed headers = "host"), and we
  // declare an UNSIGNED-PAYLOAD so the browser can stream the file body
  // without us having to hash up to ~20GB.
  const signedHeaders = 'host';

  // Build the canonical query string. These params MUST be:
  //   - URI-encoded (key and value),
  //   - sorted by encoded key name (byte order).
  // We assemble as [encKey, encVal] pairs, sort by encKey, then join.
  const queryParams = [
    ['X-Amz-Algorithm', algorithm],
    ['X-Amz-Credential', `${env.R2_ACCESS_KEY_ID}/${credentialScope}`],
    ['X-Amz-Date', amzDate],
    ['X-Amz-Expires', String(expires)],
    ['X-Amz-SignedHeaders', signedHeaders],
  ];
  const canonicalQueryString = queryParams
    .map(([k, v]) => [rfc3986(k), rfc3986(v)])
    .sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0))
    .map(([k, v]) => `${k}=${v}`)
    .join('&');

  // Canonical headers block: one "name:value\n" line per signed header, with
  // header names lowercased and values trimmed. Here, just "host".
  const canonicalHeaders = `host:${host}\n`;

  // Canonical request:
  //   METHOD \n URI \n QUERY \n CANONICAL_HEADERS \n SIGNED_HEADERS \n PAYLOAD_HASH
  // Payload hash literal is "UNSIGNED-PAYLOAD" for presigned PUTs.
  const payloadHash = 'UNSIGNED-PAYLOAD';
  const canonicalRequest = [
    'PUT',
    canonicalUri,
    canonicalQueryString,
    canonicalHeaders,
    signedHeaders,
    payloadHash,
  ].join('\n');

  // String to sign:
  //   ALGORITHM \n AMZ_DATE \n CREDENTIAL_SCOPE \n hex(SHA256(canonicalRequest))
  const hashedCanonicalRequest = await sha256Hex(canonicalRequest);
  const stringToSign = [
    algorithm,
    amzDate,
    credentialScope,
    hashedCanonicalRequest,
  ].join('\n');

  // Signature = hex( HMAC( signingKey, stringToSign ) )
  const signingKey = await getSigningKey(
    env.R2_SECRET_ACCESS_KEY,
    dateStamp,
    region,
    service,
  );
  const signature = toHex(await hmac(signingKey, stringToSign));

  // Final presigned URL = endpoint + canonical query + the computed signature.
  // X-Amz-Signature is appended AFTER signing (it is never part of the signed
  // canonical query string).
  const uploadUrl =
    `https://${host}${canonicalUri}?${canonicalQueryString}` +
    `&X-Amz-Signature=${signature}`;

  // Public URL the app stores as versions.r2_key's served location. We keep
  // `key` itself in the DB; publicUrl is the convenience CDN/public-bucket URL.
  const publicUrl = env.R2_PUBLIC_BASE.replace(/\/$/, '') + '/' + key;

  // Note: contentType is intentionally NOT signed (it is not in signedHeaders),
  // so the browser's PUT must likewise NOT send a Content-Type that we claimed
  // to sign — sending it as an unsigned header is fine for R2.
  void contentType;

  return json({ uploadUrl, key, publicUrl });
}
