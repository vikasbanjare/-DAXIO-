# Daxio — Cloud Kit

This is the **cloud kit** for Daxio, a Frame.io-style creative-review app. It turns the
browser-only demo into a real, hosted product on the cheapest viable stack: static files and
serverless functions on **Cloudflare Pages**, auth + Postgres + realtime on **Supabase**, and
big media files in **Cloudflare R2**.

## Architecture (in three sentences)

The browser app is plain ES modules (no build step) served as static files from Cloudflare Pages,
talking to Supabase for auth, the Postgres data model (workspaces → projects → assets → versions →
comments), and realtime comment updates. Large media (images and video, up to ~20 GB) is uploaded
**directly from the browser to Cloudflare R2** via a short-lived presigned PUT URL minted by a Pages
Function, so multi-GB files never pass through our server — only the resulting object key is saved
to a `versions` row. Anonymous, no-account reviewers reach a project or asset through a server-side
share-link function that uses the Supabase service-role key to bypass Row-Level Security after
validating the share token.

## What's in here

```
launch-cloud/
├── README.md                  ← you are here
├── DEPLOY.md                  ← click-by-click launch guide (start here to go live)
├── supabase-schema.sql        ← run once in Supabase → SQL Editor (see link below)
├── .env.example               ← documents the SERVER secrets set in the Cloudflare dashboard
├── _headers                   ← Cloudflare Pages caching + basic security headers
├── functions/                 ← Cloudflare Pages Functions (serverless API)
│   └── api/
│       ├── upload-url.js       ← mints the presigned R2 upload URL (AWS SigV4, zero deps)
│       └── share/[token].js    ← resolves a share link for external, no-account reviewers
└── public/                    ← everything served to the browser
    ├── config.example.js      ← copy to config.js (git-ignored) with your SUPABASE_URL + anon key
    └── lib/
        ├── supabase.js        ← singleton Supabase client + getAccessToken()
        ├── auth.js            ← getUser / onAuth / signInEmail / signInOAuth / signOut
        ├── data.js            ← workspaces, projects, assets, versions, comments + realtime
        └── upload.js          ← uploadFile(): direct-to-R2 upload via presigned PUT URL
```

### File-by-file

- **`supabase-schema.sql`** — the full Postgres schema: `profiles`, `workspaces` +
  `workspace_members`, `projects`, `assets`, `versions`, `comments` (+ replies + reactions),
  `share_links`, and `notifications`. Includes the `is_member()` helper, Row-Level Security policies
  scoped to workspace membership, triggers that auto-create a profile per auth user and make a
  workspace creator its owner, and the realtime publication for live comments. Paste it into the
  Supabase SQL Editor and run it once against a fresh project.
- **`.env.example`** — reference doc for the **server-only** secrets (`SUPABASE_URL`,
  `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE`, `R2_ACCOUNT_ID`, `R2_ACCESS_KEY_ID`,
  `R2_SECRET_ACCESS_KEY`, `R2_BUCKET`, `R2_PUBLIC_BASE`). These are **not** loaded from this file at
  runtime — set them as encrypted environment variables in the Cloudflare Pages dashboard.
- **`_headers`** — Cloudflare Pages header rules: long-immutable caching for `/lib/*` and
  `/assets/*`, never-cache for `/config.js` and HTML, plus `X-Content-Type-Options` and
  `Referrer-Policy`.
- **`public/config.example.js`** — template for the public browser config. Copy it to
  `public/config.js` (git-ignored) and fill in your Supabase project URL and **anon** key. Only
  public values go here; secrets stay server-side.
- **`public/lib/supabase.js`** — creates the one shared Supabase client from `window.DAXIO_CONFIG`
  (with `persistSession` / `autoRefreshToken` / `detectSessionInUrl`) and exports `getAccessToken()`
  for authorizing Pages Function calls.
- **`public/lib/auth.js`** — thin wrapper over `supabase.auth`: magic-link email sign-in, Google /
  Microsoft (Azure) OAuth, current-user lookup, an `onAuth(cb)` subscription, and sign-out.
- **`public/lib/data.js`** — the data layer: list/create workspaces, projects, assets and versions;
  list/add/resolve/delete comments; replies and reactions; and `subscribeComments()` for realtime.
- **`public/lib/upload.js`** — `uploadFile(file, { onProgress })`: requests a presigned URL from
  `/api/upload-url`, PUTs the bytes straight to R2 via `XMLHttpRequest` (for progress events), and
  resolves `{ r2_key, publicUrl }`.

## What's wired vs. what still needs dev finishing

**This kit is scaffolding, not a finished deployment.** Be honest with yourself about the gap.

Wired / scaffolded here:

- **Database schema** — `supabase-schema.sql` is complete and runnable: tables, RLS policies,
  membership helper, triggers, and the realtime publication.
- **Auth** — `auth.js` covers magic-link and OAuth sign-in/out against Supabase.
- **Data layer** — `data.js` exposes the full CRUD + realtime API surface the UI is expected to
  call.
- **R2 direct-upload (client side)** — `upload.js` implements the browser half of the presigned-PUT
  flow, including progress reporting.
- **Pages Functions (server side)** — both serverless endpoints are authored and present:
  `functions/api/upload-url.js` (verifies the Supabase JWT, then mints an AWS-SigV4 presigned R2 PUT
  URL using Web Crypto — zero npm deps) and `functions/api/share/[token].js` (looks up a share link
  with the service-role key and returns the project/asset + versions + comments for an external,
  no-account viewer).

Still needs developer finishing:

- **Wiring into the existing review UI** — the demo's review surface (player, comment sidebar,
  version switcher, status chips) still needs to be connected to `auth.js` / `data.js` /
  `upload.js` so reads, writes, uploads, and realtime updates flow against the live backend instead
  of the in-browser mock.
- **End-to-end testing** — none of the round trips (sign in → create project → upload a version →
  comment in realtime → share externally) have been exercised against a real Supabase + R2
  deployment yet. This is the bulk of the remaining work.
- **Provider + storage setup** — enabling Email + Google + Microsoft (Azure) auth providers in
  Supabase, creating the R2 bucket and API token, and setting the encrypted Cloudflare env vars.

## Setup

1. Create a Supabase project and run [`supabase-schema.sql`](./supabase-schema.sql) once in the SQL
   Editor.
2. Copy `public/config.example.js` to `public/config.js` and fill in your Supabase URL + anon key.
3. Set the server secrets from `.env.example` as encrypted environment variables in the Cloudflare
   Pages dashboard.
4. Deploy on Cloudflare Pages (the `functions/api/` endpoints are already included and auto-detected).

For the full step-by-step deploy walkthrough — Cloudflare Pages project, R2 bucket and tokens,
Supabase providers, and env vars — see **[DEPLOY.md](./DEPLOY.md)**.
