-- ============================================================
-- Daxio — Supabase schema (cloud kit)
-- Workspaces → projects → assets → versions → comments, with
-- team membership, share links, notifications and Row-Level Security.
-- Paste into Supabase → SQL Editor → New query → Run (once, fresh project).
-- ============================================================

create extension if not exists "pgcrypto";

-- 1) Profiles ----------------------------------------------------
create table if not exists public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text,
  email       text,
  avatar_url  text,
  created_at  timestamptz default now()
);
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, email, avatar_url)
  values (new.id,
          coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', split_part(new.email,'@',1)),
          new.email, new.raw_user_meta_data->>'avatar_url')
  on conflict (id) do nothing;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- 2) Workspaces + members (the "space" you invite people into) ---
create table if not exists public.workspaces (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  owner_id    uuid references public.profiles(id),
  created_at  timestamptz default now()
);
create table if not exists public.workspace_members (
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id      uuid not null references public.profiles(id) on delete cascade,
  role         text not null default 'member',   -- owner | admin | member
  created_at   timestamptz default now(),
  primary key (workspace_id, user_id)
);
-- creator automatically becomes the owner-member of a new workspace
create or replace function public.handle_new_workspace()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.workspace_members (workspace_id, user_id, role)
  values (new.id, new.owner_id, 'owner') on conflict do nothing;
  return new;
end; $$;
drop trigger if exists on_workspace_created on public.workspaces;
create trigger on_workspace_created after insert on public.workspaces
  for each row execute function public.handle_new_workspace();

-- membership helper used by every policy below
create or replace function public.is_member(ws uuid)
returns boolean language sql security definer stable set search_path = public as $$
  select exists (select 1 from public.workspace_members m
                 where m.workspace_id = ws and m.user_id = auth.uid());
$$;

-- 3) Projects (multiple per workspace) ---------------------------
create table if not exists public.projects (
  id           uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  name         text not null,
  color        text,
  created_by   uuid references public.profiles(id),
  created_at   timestamptz default now()
);
create index if not exists projects_ws_idx on public.projects(workspace_id);

-- 4) Assets (a thing under review) — now lives inside a project --
create table if not exists public.assets (
  id           uuid primary key default gen_random_uuid(),
  project_id   uuid not null references public.projects(id) on delete cascade,
  title        text not null,
  status       text not null default 'In review',   -- In review | Changes requested | Approved
  created_by   uuid references public.profiles(id),
  created_at   timestamptz default now()
);
create index if not exists assets_project_idx on public.assets(project_id);

-- 5) Versions (V1, V2 … one media file each) ---------------------
create table if not exists public.versions (
  id              uuid primary key default gen_random_uuid(),
  asset_id        uuid not null references public.assets(id) on delete cascade,
  label           text not null default 'V1',
  kind            text,                 -- 'image' | 'video'
  r2_key          text,                 -- object key in the R2 bucket (raw upload)
  stream_uid      text,                 -- Cloudflare Stream uid (transcoded video) if used
  mux_playback_id text,                 -- or Mux playback id, if you use Mux instead
  duration        numeric,
  created_by      uuid references public.profiles(id),
  created_at      timestamptz default now()
);
create index if not exists versions_asset_idx on public.versions(asset_id);

-- 6) Comments + replies + reactions ------------------------------
create table if not exists public.comments (
  id          uuid primary key default gen_random_uuid(),
  version_id  uuid not null references public.versions(id) on delete cascade,
  author      uuid references public.profiles(id),
  guest_name  text,                     -- set when an external (no-account) reviewer comments
  body        text not null,
  t           numeric, in_a numeric, in_b numeric,
  point_x     numeric, point_y numeric,
  drawing     jsonb,
  resolved    boolean default false,
  created_at  timestamptz default now()
);
create index if not exists comments_version_idx on public.comments(version_id);
create table if not exists public.comment_replies (
  id uuid primary key default gen_random_uuid(),
  comment_id uuid not null references public.comments(id) on delete cascade,
  author uuid references public.profiles(id), guest_name text,
  body text not null, created_at timestamptz default now()
);
create table if not exists public.comment_reactions (
  id uuid primary key default gen_random_uuid(),
  comment_id uuid not null references public.comments(id) on delete cascade,
  user_id uuid references public.profiles(id), emoji text not null,
  unique (comment_id, user_id, emoji)
);

-- 7) Share links (give a project/asset to someone, no account) ---
create table if not exists public.share_links (
  id          uuid primary key default gen_random_uuid(),
  token       text not null unique default encode(gen_random_bytes(12),'hex'),
  project_id  uuid references public.projects(id) on delete cascade,
  asset_id    uuid references public.assets(id) on delete cascade,
  can_comment boolean default true,
  password    text,                     -- optional; checked server-side
  expires_at  timestamptz,
  created_by  uuid references public.profiles(id),
  created_at  timestamptz default now()
);
create index if not exists share_token_idx on public.share_links(token);

-- 8) Notifications (mention / assigned / status / reply) ---------
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  recipient uuid references public.profiles(id),
  type text, body text,
  asset_id uuid references public.assets(id) on delete cascade,
  comment_id uuid references public.comments(id) on delete set null,
  read boolean default false, created_at timestamptz default now()
);

-- 9) Row-Level Security ------------------------------------------
-- Members of a workspace can read/write everything inside it. External
-- (anonymous) sharing is handled by a server function using the service
-- role key (see functions/api/share) which validates the share token.
alter table public.profiles            enable row level security;
alter table public.workspaces          enable row level security;
alter table public.workspace_members   enable row level security;
alter table public.projects            enable row level security;
alter table public.assets              enable row level security;
alter table public.versions            enable row level security;
alter table public.comments            enable row level security;
alter table public.comment_replies     enable row level security;
alter table public.comment_reactions   enable row level security;
alter table public.share_links         enable row level security;
alter table public.notifications       enable row level security;

-- profiles: anyone signed in can read; you edit your own
drop policy if exists "profiles read" on public.profiles;
create policy "profiles read"  on public.profiles for select using (auth.role()='authenticated');
drop policy if exists "profiles write" on public.profiles;
create policy "profiles write" on public.profiles for update using (id = auth.uid());

-- workspaces: members read; any authed user can create; owner can update/delete
drop policy if exists "ws read"   on public.workspaces;
create policy "ws read"   on public.workspaces for select using (public.is_member(id));
drop policy if exists "ws insert" on public.workspaces;
create policy "ws insert" on public.workspaces for insert with check (owner_id = auth.uid());
drop policy if exists "ws manage" on public.workspaces;
create policy "ws manage" on public.workspaces for update using (owner_id = auth.uid());

-- members: you can see the membership rows of workspaces you belong to
drop policy if exists "wm read"  on public.workspace_members;
create policy "wm read"  on public.workspace_members for select using (public.is_member(workspace_id));
drop policy if exists "wm write" on public.workspace_members;
create policy "wm write" on public.workspace_members for all
  using (exists (select 1 from public.workspaces w where w.id=workspace_id and w.owner_id=auth.uid()))
  with check (exists (select 1 from public.workspaces w where w.id=workspace_id and w.owner_id=auth.uid()));

-- projects: scoped to workspace membership
drop policy if exists "proj rw" on public.projects;
create policy "proj rw" on public.projects for all
  using (public.is_member(workspace_id)) with check (public.is_member(workspace_id));

-- assets / versions / comments: scoped by walking up to the workspace
drop policy if exists "asset rw" on public.assets;
create policy "asset rw" on public.assets for all
  using (public.is_member((select p.workspace_id from public.projects p where p.id=project_id)))
  with check (public.is_member((select p.workspace_id from public.projects p where p.id=project_id)));

drop policy if exists "ver rw" on public.versions;
create policy "ver rw" on public.versions for all
  using (public.is_member((select p.workspace_id from public.projects p join public.assets a on a.project_id=p.id where a.id=asset_id)))
  with check (public.is_member((select p.workspace_id from public.projects p join public.assets a on a.project_id=p.id where a.id=asset_id)));

drop policy if exists "cmt rw" on public.comments;
create policy "cmt rw" on public.comments for all
  using (public.is_member((select p.workspace_id from public.projects p join public.assets a on a.project_id=p.id join public.versions v on v.asset_id=a.id where v.id=version_id)))
  with check (public.is_member((select p.workspace_id from public.projects p join public.assets a on a.project_id=p.id join public.versions v on v.asset_id=a.id where v.id=version_id)));

drop policy if exists "reply rw" on public.comment_replies;
create policy "reply rw" on public.comment_replies for all using (auth.role()='authenticated') with check (auth.role()='authenticated');
drop policy if exists "react rw" on public.comment_reactions;
create policy "react rw" on public.comment_reactions for all using (auth.role()='authenticated') with check (auth.role()='authenticated');

-- share links: managed by workspace members of the linked project
drop policy if exists "share rw" on public.share_links;
create policy "share rw" on public.share_links for all
  using (public.is_member((select coalesce(p.workspace_id,(select p2.workspace_id from public.projects p2 join public.assets a on a.project_id=p2.id where a.id=share_links.asset_id))
                           from public.projects p where p.id=share_links.project_id)))
  with check (created_by = auth.uid());

-- notifications: only your own
drop policy if exists "notif read" on public.notifications;
create policy "notif read" on public.notifications for select using (recipient = auth.uid());
drop policy if exists "notif update" on public.notifications;
create policy "notif update" on public.notifications for update using (recipient = auth.uid());

-- 10) Realtime (live comments / reactions / presence) -----------
alter publication supabase_realtime add table public.comments;
alter publication supabase_realtime add table public.comment_replies;
alter publication supabase_realtime add table public.comment_reactions;

-- Done. Media (image/video) is NOT stored here — it goes to Cloudflare R2
-- (see functions/api/upload-url). Only the r2_key / stream_uid is saved above.
-- Next: Authentication → Providers → enable Email + Google + Microsoft (Azure).
